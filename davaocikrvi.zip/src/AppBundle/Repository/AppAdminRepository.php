<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

class AppAdminRepository extends EntityRepository
{

}