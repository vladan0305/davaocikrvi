<?php

/* AppBundle:admin/request:edit.html.twig */
class __TwigTemplate_12c14436baf20d02f715b4226a5dbba517c723daeeb0e13ec684b6a312f79225 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/admin/master/layout.html.twig", "AppBundle:admin/request:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/admin/master/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["page_title"] = "Dodavanje Novog Zahteva";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "
    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">
            Izmena Zahteva

            <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_countries");
        echo "\" class=\"btn btn-success\" style=\"float: right;\">
                Nazad
            </a>
        </h1>
    </div>

    <div class=\"col-lg-12\">
        <div class=\"panel panel-default\">
            <div class=\"panel-heading\">
                Forma za izmenu Zahteva
            </div>
            <div class=\"panel-body\">

                ";
        // line 23
        $this->loadTemplate("@App/admin/request/blocks/form.html.twig", "AppBundle:admin/request:edit.html.twig", 23)->display($context);
        // line 24
        echo "
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AppBundle:admin/request:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 24,  57 => 23,  41 => 10,  34 => 5,  31 => 4,  27 => 1,  25 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppBundle:admin/request:edit.html.twig", "/Users/backend2/Desktop/Workspace/davaocikrvi/src/AppBundle/Resources/views/admin/request/edit.html.twig");
    }
}
