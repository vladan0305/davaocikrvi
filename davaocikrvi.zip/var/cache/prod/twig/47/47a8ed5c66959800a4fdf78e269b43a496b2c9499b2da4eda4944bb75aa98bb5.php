<?php

/* @App/front/master/layout.html.twig */
class __TwigTemplate_da2a753032b6021432516b406ed549088f7d3cd3979dedf8b3966f1320a67a3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>
        ";
        // line 12
        if (array_key_exists("page_title", $context)) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["page_title"]) ? $context["page_title"] : null), "html", null, true);
            echo " | Davaoci Krvi ";
        }
        // line 13
        echo "    </title>

    ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 19
        echo "
</head>

<body>

    ";
        // line 24
        $this->loadTemplate("@App/front/master/navigationbar.html.twig", "@App/front/master/layout.html.twig", 24)->display($context);
        // line 25
        echo "
    <div class=\"container\">

        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">

                ";
        // line 31
        $this->displayBlock('body', $context, $blocks);
        // line 32
        echo "
            </div>
        </div>

    </div>

    ";
        // line 38
        $this->displayBlock('javascripts', $context, $blocks);
        // line 42
        echo "
</body>
</html>
";
    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 16
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/front/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <style> body {padding-top: 70px;} </style>
    ";
    }

    // line 31
    public function block_body($context, array $blocks = array())
    {
    }

    // line 38
    public function block_javascripts($context, array $blocks = array())
    {
        // line 39
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/front/js/jquery.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/front/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    ";
    }

    public function getTemplateName()
    {
        return "@App/front/master/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 40,  102 => 39,  99 => 38,  94 => 31,  86 => 16,  83 => 15,  76 => 42,  74 => 38,  66 => 32,  64 => 31,  56 => 25,  54 => 24,  47 => 19,  45 => 15,  41 => 13,  35 => 12,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@App/front/master/layout.html.twig", "/Users/backend2/Desktop/Workspace/davaocikrvi/src/AppBundle/Resources/views/front/master/layout.html.twig");
    }
}
