<?php

/* AppBundle:admin/request:index.html.twig */
class __TwigTemplate_5c1cd58fb13fba2b9a00ffcd676c78d881ece5f9b17b9bddc4ad5bbde96780d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/admin/master/layout.html.twig", "AppBundle:admin/request:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/admin/master/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["page_title"] = "Zahtevi";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "
    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">
            Modul Zahteva

            <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_requests_create");
        echo "\" class=\"btn btn-success\" style=\"float: right;\">
                Dodaj Novi Zahtev
            </a>
        </h1>
    </div>

    <div class=\"col-lg-12\">
        <div class=\"panel panel-default\">

            <div class=\"panel-heading\">
                Naziv Tabele
            </div>

            <div class=\"panel-body\">
                <div>
                    <table class=\"table table-striped table-bordered table-hover\">
                        <thead>
                            <tr>
                                <th style=\"width: 4%\">#</th>
                                <th class=\"text-center\">Zahtev</th>
                                <th class=\"text-center\" style=\"width: 20%\">Akcije</th>
                            </tr>
                        </thead>
                        <tbody>

                        ";
        // line 35
        if ( !twig_test_empty((isset($context["requests"]) ? $context["requests"] : null))) {
            // line 36
            echo "
                            ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["requests"]) ? $context["requests"] : null));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["request"]) {
                // line 38
                echo "                            <tr>

                                <td class=\"text-center\">";
                // line 40
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 41
                echo twig_escape_filter($this->env, $this->getAttribute($context["request"], "description", array()), "html", null, true);
                echo "</td>

                                <td class=\"text-center\">
                                    <a href=\"";
                // line 44
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_requests_edit", array("id" => $this->getAttribute($context["request"], "getId", array(), "method"))), "html", null, true);
                echo "\"
                                       class=\"btn btn-primary\">
                                       <i class=\"fa fa-pencil\"></i>
                                    </a>
                                    <a href=\"";
                // line 48
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_requests_delete", array("id" => $this->getAttribute($context["request"], "getId", array(), "method"))), "html", null, true);
                echo "\" class=\"btn btn-danger\">
                                        <i class=\"fa fa-trash\"></i>
                                    </a>
                                </td>

                            </tr>
                            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['request'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 55
            echo "                        ";
        }
        // line 56
        echo "
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "AppBundle:admin/request:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 56,  133 => 55,  112 => 48,  105 => 44,  99 => 41,  95 => 40,  91 => 38,  74 => 37,  71 => 36,  69 => 35,  41 => 10,  34 => 5,  31 => 4,  27 => 1,  25 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppBundle:admin/request:index.html.twig", "/Users/backend2/Desktop/Workspace/davaocikrvi/src/AppBundle/Resources/views/admin/request/index.html.twig");
    }
}
