<?php

/* @App/admin/master/sidebar.html.twig */
class __TwigTemplate_fcb5f0102611fd248d94c35633f809e15ce2251105a8e4858153de1d743968c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-default navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">

    <div class=\"navbar-header\">
        <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
        </button>
        <a class=\"navbar-brand\" href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_homepage");
        echo "\">CMS Admin</a>
    </div>

    <ul class=\"nav navbar-top-links navbar-right\">
    </ul>


    <div class=\"navbar-default sidebar\" role=\"navigation\">
        <div class=\"sidebar-nav navbar-collapse\">
            <ul class=\"nav\" id=\"side-menu\">

                <!-- OVDE TREBA DA VAM IDU SVI MENIJI KOJI SE VEZUJU PREKO RUTA ZA KONTROLERE I AKCIJE -->
                <li>
                    <a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_homepage");
        echo "\">
                        <i class=\"fa fa-home\"></i> Dashboard
                    </a>
                </li>

                <li>
                    <a href=\"#\">
                        <i class=\"fa fa-map-marker\"></i> Lokacije
                        <span class=\"fa arrow\"></span>
                    </a>
                    <ul class=\"nav nav-second-level collapse\" aria-expanded=\"false\">
                        <li>
                            <a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_countries");
        echo "\"> Države </a>
                        </li>
                        <li>
                            <a> Gradovi </a>
                        </li>
                    </ul>
                </li>
                
                 <li>
                    <a href=\"#\">
                        <i class=\"fa fa-map-marker\"></i> Administratori
                        <span class=\"fa arrow\"></span>
                    </a>
                    <ul class=\"nav nav-second-level collapse\" aria-expanded=\"false\">
                        <li>
                            <a href=\"";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_admins");
        echo "\"> Admin </a>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>
    </div>

</nav>";
    }

    public function getTemplateName()
    {
        return "@App/admin/master/sidebar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 50,  61 => 35,  46 => 23,  30 => 10,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@App/admin/master/sidebar.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\admin\\master\\sidebar.html.twig");
    }
}
