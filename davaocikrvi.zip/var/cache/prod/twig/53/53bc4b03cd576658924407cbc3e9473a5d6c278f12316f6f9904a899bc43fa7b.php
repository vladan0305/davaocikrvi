<?php

/* @App/admin/admin/index.html.twig */
class __TwigTemplate_48ddd993a909ec99874e075773bb5a334afc2f0e0a63283b6694704e9f97f513 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/admin/master/layout.html.twig", "@App/admin/admin/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/admin/master/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["page_title"] = "Administratori";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "
    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">
            Modul Administratora

            <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_admins_create");
        echo "\" class=\"btn btn-success\" style=\"float: right;\">
                Dodaj Novog
            </a>
        </h1>
    </div>

    <div class=\"col-lg-12\">
        <div class=\"panel panel-default\">

            <div class=\"panel-heading\">
                Naziv Tabele
            </div>

            <div class=\"panel-body\">
                <div>
                    <table class=\"table table-striped table-bordered table-hover\">
                        <thead>
                            <tr>
                                <th style=\"width: 4%\">#</th>
                                <th class=\"text-center\">Ime</th>
                                <th class=\"text-center\">Prezime</th>
                                <th class=\"text-center\">Email</th>
                                <th class=\"text-center\">Sifra</th>
                                <th class=\"text-center\" style=\"width: 20%\">Akcije</th>
                            </tr>
                        </thead>
                        <tbody>

                        ";
        // line 38
        if ( !twig_test_empty((isset($context["admins"]) ? $context["admins"] : null))) {
            // line 39
            echo "
                            ";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["admins"]) ? $context["admins"] : null));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["admin"]) {
                // line 41
                echo "                            <tr>

                                <td class=\"text-center\">";
                // line 43
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 44
                echo twig_escape_filter($this->env, $this->getAttribute($context["admin"], "firstName", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 45
                echo twig_escape_filter($this->env, $this->getAttribute($context["admin"], "lastName", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 46
                echo twig_escape_filter($this->env, $this->getAttribute($context["admin"], "email", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute($context["admin"], "password", array()), "html", null, true);
                echo "</td>

                                <td class=\"text-center\">
                                    <a href=\"";
                // line 50
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_admins_edit", array("id" => $this->getAttribute($context["admin"], "getId", array(), "method"))), "html", null, true);
                echo "\"
                                       class=\"btn btn-primary\">
                                       <i class=\"fa fa-pencil\"></i>
                                    </a>
                                    <a href=\"";
                // line 54
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_admins_delete", array("id" => $this->getAttribute($context["admin"], "getId", array(), "method"))), "html", null, true);
                echo "\" class=\"btn btn-danger\">
                                        <i class=\"fa fa-trash\"></i>
                                    </a>
                                </td>

                            </tr>
                            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['admin'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 61
            echo "                        ";
        }
        // line 62
        echo "
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "@App/admin/admin/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 62,  148 => 61,  127 => 54,  120 => 50,  114 => 47,  110 => 46,  106 => 45,  102 => 44,  98 => 43,  94 => 41,  77 => 40,  74 => 39,  72 => 38,  41 => 10,  34 => 5,  31 => 4,  27 => 1,  25 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@App/admin/admin/index.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\admin\\admin\\index.html.twig");
    }
}
