<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/admin')) {
            // admin_homepage
            if ($pathinfo === '/admin/dashboard') {
                return array (  '_controller' => 'AppBundle\\Controller\\Admin\\IndexController::indexAction',  '_route' => 'admin_homepage',);
            }

            if (0 === strpos($pathinfo, '/admin/countries')) {
                // admin_countries
                if ($pathinfo === '/admin/countries') {
                    return array (  '_controller' => 'AppBundle\\Controller\\Admin\\CountryController::indexAction',  '_route' => 'admin_countries',);
                }

                // admin_countries_create
                if ($pathinfo === '/admin/countries/create') {
                    return array (  '_controller' => 'AppBundle\\Controller\\Admin\\CountryController::createAction',  '_route' => 'admin_countries_create',);
                }

                // admin_countries_edit
                if (0 === strpos($pathinfo, '/admin/countries/edit') && preg_match('#^/admin/countries/edit/(?P<id>\\d+)/?$#s', $pathinfo, $matches)) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_countries_edit');
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_countries_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CountryController::editAction',));
                }

                // admin_countries_delete
                if (0 === strpos($pathinfo, '/admin/countries/delete') && preg_match('#^/admin/countries/delete/(?P<id>\\d+)/?$#s', $pathinfo, $matches)) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_countries_delete');
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_countries_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\CountryController::deleteAction',));
                }

            }

            if (0 === strpos($pathinfo, '/admin/admins')) {
                // admin_admins
                if ($pathinfo === '/admin/admins') {
                    return array (  '_controller' => 'AppBundle\\Controller\\Admin\\AdminController::indexAction',  '_route' => 'admin_admins',);
                }

                // admin_admins_create
                if ($pathinfo === '/admin/admins/create') {
                    return array (  '_controller' => 'AppBundle\\Controller\\Admin\\AdminController::createAction',  '_route' => 'admin_admins_create',);
                }

                // admin_admins_edit
                if (0 === strpos($pathinfo, '/admin/admins/edit') && preg_match('#^/admin/admins/edit/(?P<id>\\d+)/?$#s', $pathinfo, $matches)) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_admins_edit');
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_admins_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\AdminController::editAction',));
                }

                // admin_admins_delete
                if (0 === strpos($pathinfo, '/admin/admins/delete') && preg_match('#^/admin/admins/delete/(?P<id>\\d+)/?$#s', $pathinfo, $matches)) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_admins_delete');
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_admins_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\AdminController::deleteAction',));
                }

            }

            if (0 === strpos($pathinfo, '/admin/requests')) {
                // admin_requests
                if ($pathinfo === '/admin/requests') {
                    return array (  '_controller' => 'AppBundle\\Controller\\Admin\\RequestController::indexAction',  '_route' => 'admin_requests',);
                }

                // admin_requests_create
                if ($pathinfo === '/admin/requests/create') {
                    return array (  '_controller' => 'AppBundle\\Controller\\Admin\\RequestController::createAction',  '_route' => 'admin_requests_create',);
                }

                // admin_requests_edit
                if (0 === strpos($pathinfo, '/admin/requests/edit') && preg_match('#^/admin/requests/edit/(?P<id>\\d+)/?$#s', $pathinfo, $matches)) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_requests_edit');
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_requests_edit')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\RequestController::editAction',));
                }

                // admin_requests_delete
                if (0 === strpos($pathinfo, '/admin/requests/delete') && preg_match('#^/admin/requests/delete/(?P<id>\\d+)/?$#s', $pathinfo, $matches)) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_requests_delete');
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_requests_delete')), array (  '_controller' => 'AppBundle\\Controller\\Admin\\RequestController::deleteAction',));
                }

            }

        }

        // front_homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'front_homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\Front\\IndexController::indexAction',  '_route' => 'front_homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
