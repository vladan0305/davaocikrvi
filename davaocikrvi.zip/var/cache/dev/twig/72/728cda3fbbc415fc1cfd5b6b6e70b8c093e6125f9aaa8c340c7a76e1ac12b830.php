<?php

/* @App/front/request/request.html.twig */
class __TwigTemplate_9bf87878258fcd86a8df39367d4c15e0a945a8157eb969a32a902a8c386f1560 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/front/master/layout.html.twig", "@App/front/request/request.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/front/master/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a60b60faf96b0cac2df457f948a170681c3389166c859761dec779d30f318e24 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a60b60faf96b0cac2df457f948a170681c3389166c859761dec779d30f318e24->enter($__internal_a60b60faf96b0cac2df457f948a170681c3389166c859761dec779d30f318e24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/front/request/request.html.twig"));

        $__internal_58feb314c6f9d5a28a9a3b799dcf4f59504a77df94f7895164ca53608804f720 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58feb314c6f9d5a28a9a3b799dcf4f59504a77df94f7895164ca53608804f720->enter($__internal_58feb314c6f9d5a28a9a3b799dcf4f59504a77df94f7895164ca53608804f720_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/front/request/request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a60b60faf96b0cac2df457f948a170681c3389166c859761dec779d30f318e24->leave($__internal_a60b60faf96b0cac2df457f948a170681c3389166c859761dec779d30f318e24_prof);

        
        $__internal_58feb314c6f9d5a28a9a3b799dcf4f59504a77df94f7895164ca53608804f720->leave($__internal_58feb314c6f9d5a28a9a3b799dcf4f59504a77df94f7895164ca53608804f720_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6e4cc562d47000129a0befb43647f3ef284be61ef46e449fb70980e584327107 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e4cc562d47000129a0befb43647f3ef284be61ef46e449fb70980e584327107->enter($__internal_6e4cc562d47000129a0befb43647f3ef284be61ef46e449fb70980e584327107_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5c2fcd29f75912493afaab6feb8975a2ce2003a92151634134801dc35f5d837c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c2fcd29f75912493afaab6feb8975a2ce2003a92151634134801dc35f5d837c->enter($__internal_5c2fcd29f75912493afaab6feb8975a2ce2003a92151634134801dc35f5d837c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    
    ";
        // line 5
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 6
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 7
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    
     ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    
     ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 15
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

";
        
        $__internal_5c2fcd29f75912493afaab6feb8975a2ce2003a92151634134801dc35f5d837c->leave($__internal_5c2fcd29f75912493afaab6feb8975a2ce2003a92151634134801dc35f5d837c_prof);

        
        $__internal_6e4cc562d47000129a0befb43647f3ef284be61ef46e449fb70980e584327107->leave($__internal_6e4cc562d47000129a0befb43647f3ef284be61ef46e449fb70980e584327107_prof);

    }

    public function getTemplateName()
    {
        return "@App/front/request/request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 15,  82 => 14,  78 => 13,  73 => 11,  69 => 10,  65 => 9,  60 => 7,  56 => 6,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@App/front/master/layout.html.twig' %}

{% block body %}
    
    {{ form_start(form) }}
    {{ form_widget(form) }}
    {{ form_end(form) }}
    
     {{ form_start(form) }}
    {{ form_widget(form) }}
    {{ form_end(form) }}
    
     {{ form_start(form) }}
    {{ form_widget(form) }}
    {{ form_end(form) }}

{% endblock %}
", "@App/front/request/request.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\front\\request\\request.html.twig");
    }
}
