<?php

/* @App/front/index/index.html.twig */
class __TwigTemplate_25b10cfba66055cab4f01c5f0e0edd5887d085fb87587e1ad0b89520e4493e3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/front/master/layout.html.twig", "@App/front/index/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/front/master/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f95d005afcb643db4c268e3e6a534671594155a53ffca8b0271794b27df5320 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f95d005afcb643db4c268e3e6a534671594155a53ffca8b0271794b27df5320->enter($__internal_8f95d005afcb643db4c268e3e6a534671594155a53ffca8b0271794b27df5320_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/front/index/index.html.twig"));

        $__internal_ee9ae28c597cfd535159adca888614599ac4c17e74390422892aa115dba22947 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee9ae28c597cfd535159adca888614599ac4c17e74390422892aa115dba22947->enter($__internal_ee9ae28c597cfd535159adca888614599ac4c17e74390422892aa115dba22947_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/front/index/index.html.twig"));

        // line 2
        $context["page_title"] = "Home";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8f95d005afcb643db4c268e3e6a534671594155a53ffca8b0271794b27df5320->leave($__internal_8f95d005afcb643db4c268e3e6a534671594155a53ffca8b0271794b27df5320_prof);

        
        $__internal_ee9ae28c597cfd535159adca888614599ac4c17e74390422892aa115dba22947->leave($__internal_ee9ae28c597cfd535159adca888614599ac4c17e74390422892aa115dba22947_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_f452e4a975215733ce63ff895bda6a959f30d09b8bc3878e3f2c3fed1c70e641 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f452e4a975215733ce63ff895bda6a959f30d09b8bc3878e3f2c3fed1c70e641->enter($__internal_f452e4a975215733ce63ff895bda6a959f30d09b8bc3878e3f2c3fed1c70e641_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a1f39d2f4379a28a8db8d59c87a2a131bca2b5e239648e052e1a3fb2b5089d10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1f39d2f4379a28a8db8d59c87a2a131bca2b5e239648e052e1a3fb2b5089d10->enter($__internal_a1f39d2f4379a28a8db8d59c87a2a131bca2b5e239648e052e1a3fb2b5089d10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <h1>Ovo je frontend view skripta</h1>
    <p class=\"lead\">Idemo dalje</p>
    <ul class=\"list-unstyled\">
        <li>Bootstrap v3.3.7</li>
        <li>jQuery v1.11.1</li>
    </ul>

    <h2><a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_homepage");
        echo "\">Udji na ADMIN</a> </h2>
";
        
        $__internal_a1f39d2f4379a28a8db8d59c87a2a131bca2b5e239648e052e1a3fb2b5089d10->leave($__internal_a1f39d2f4379a28a8db8d59c87a2a131bca2b5e239648e052e1a3fb2b5089d10_prof);

        
        $__internal_f452e4a975215733ce63ff895bda6a959f30d09b8bc3878e3f2c3fed1c70e641->leave($__internal_f452e4a975215733ce63ff895bda6a959f30d09b8bc3878e3f2c3fed1c70e641_prof);

    }

    public function getTemplateName()
    {
        return "@App/front/index/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 13,  52 => 5,  43 => 4,  33 => 1,  31 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@App/front/master/layout.html.twig' %}
{% set page_title = 'Home' %}

{% block body %}

    <h1>Ovo je frontend view skripta</h1>
    <p class=\"lead\">Idemo dalje</p>
    <ul class=\"list-unstyled\">
        <li>Bootstrap v3.3.7</li>
        <li>jQuery v1.11.1</li>
    </ul>

    <h2><a href=\"{{ path('admin_homepage') }}\">Udji na ADMIN</a> </h2>
{% endblock %}", "@App/front/index/index.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\front\\index\\index.html.twig");
    }
}
