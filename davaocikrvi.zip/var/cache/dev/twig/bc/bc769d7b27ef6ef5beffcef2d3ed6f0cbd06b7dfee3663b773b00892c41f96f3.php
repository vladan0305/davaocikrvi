<?php

/* @App/admin/admin/index.html.twig */
class __TwigTemplate_832799ea484fc6782d763882fdb286d9b389ebaadb25d5ed8be33e38121e89f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/admin/master/layout.html.twig", "@App/admin/admin/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/admin/master/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b0e74489c3a21b2a7087a6cea283c1183bdd2c5be7a40dd0fa389637798a7ba5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b0e74489c3a21b2a7087a6cea283c1183bdd2c5be7a40dd0fa389637798a7ba5->enter($__internal_b0e74489c3a21b2a7087a6cea283c1183bdd2c5be7a40dd0fa389637798a7ba5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/admin/index.html.twig"));

        $__internal_cab252c75b5e36badd37c40755d3ff8ff85f1f0f8e3b2592b48d3582d19309f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cab252c75b5e36badd37c40755d3ff8ff85f1f0f8e3b2592b48d3582d19309f3->enter($__internal_cab252c75b5e36badd37c40755d3ff8ff85f1f0f8e3b2592b48d3582d19309f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/admin/index.html.twig"));

        // line 2
        $context["page_title"] = "Administratori";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b0e74489c3a21b2a7087a6cea283c1183bdd2c5be7a40dd0fa389637798a7ba5->leave($__internal_b0e74489c3a21b2a7087a6cea283c1183bdd2c5be7a40dd0fa389637798a7ba5_prof);

        
        $__internal_cab252c75b5e36badd37c40755d3ff8ff85f1f0f8e3b2592b48d3582d19309f3->leave($__internal_cab252c75b5e36badd37c40755d3ff8ff85f1f0f8e3b2592b48d3582d19309f3_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_b7f2e6fae554435a17eae78beb42b2da0b5d758db85b0153c88e0d27ac99c6c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b7f2e6fae554435a17eae78beb42b2da0b5d758db85b0153c88e0d27ac99c6c0->enter($__internal_b7f2e6fae554435a17eae78beb42b2da0b5d758db85b0153c88e0d27ac99c6c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1b12b564591479ae3fce2139760bf51883b2ddb6413787e33101f2febd1c8565 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b12b564591479ae3fce2139760bf51883b2ddb6413787e33101f2febd1c8565->enter($__internal_1b12b564591479ae3fce2139760bf51883b2ddb6413787e33101f2febd1c8565_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">
            Modul Administratora

            <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_admins_create");
        echo "\" class=\"btn btn-success\" style=\"float: right;\">
                Dodaj Novog
            </a>
        </h1>
    </div>

    <div class=\"col-lg-12\">
        <div class=\"panel panel-default\">

            <div class=\"panel-heading\">
                Naziv Tabele
            </div>

            <div class=\"panel-body\">
                <div>
                    <table class=\"table table-striped table-bordered table-hover\">
                        <thead>
                            <tr>
                                <th style=\"width: 4%\">#</th>
                                <th class=\"text-center\">Ime</th>
                                <th class=\"text-center\">Prezime</th>
                                <th class=\"text-center\">Email</th>
                                <th class=\"text-center\">Sifra</th>
                                <th class=\"text-center\" style=\"width: 20%\">Akcije</th>
                            </tr>
                        </thead>
                        <tbody>

                        ";
        // line 38
        if ( !twig_test_empty((isset($context["admins"]) ? $context["admins"] : $this->getContext($context, "admins")))) {
            // line 39
            echo "
                            ";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["admins"]) ? $context["admins"] : $this->getContext($context, "admins")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["admin"]) {
                // line 41
                echo "                            <tr>

                                <td class=\"text-center\">";
                // line 43
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 44
                echo twig_escape_filter($this->env, $this->getAttribute($context["admin"], "firstName", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 45
                echo twig_escape_filter($this->env, $this->getAttribute($context["admin"], "lastName", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 46
                echo twig_escape_filter($this->env, $this->getAttribute($context["admin"], "email", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute($context["admin"], "password", array()), "html", null, true);
                echo "</td>

                                <td class=\"text-center\">
                                    <a href=\"";
                // line 50
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_admins_edit", array("id" => $this->getAttribute($context["admin"], "getId", array(), "method"))), "html", null, true);
                echo "\"
                                       class=\"btn btn-primary\">
                                       <i class=\"fa fa-pencil\"></i>
                                    </a>
                                    <a href=\"";
                // line 54
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_admins_delete", array("id" => $this->getAttribute($context["admin"], "getId", array(), "method"))), "html", null, true);
                echo "\" class=\"btn btn-danger\">
                                        <i class=\"fa fa-trash\"></i>
                                    </a>
                                </td>

                            </tr>
                            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['admin'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 61
            echo "                        ";
        }
        // line 62
        echo "
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_1b12b564591479ae3fce2139760bf51883b2ddb6413787e33101f2febd1c8565->leave($__internal_1b12b564591479ae3fce2139760bf51883b2ddb6413787e33101f2febd1c8565_prof);

        
        $__internal_b7f2e6fae554435a17eae78beb42b2da0b5d758db85b0153c88e0d27ac99c6c0->leave($__internal_b7f2e6fae554435a17eae78beb42b2da0b5d758db85b0153c88e0d27ac99c6c0_prof);

    }

    public function getTemplateName()
    {
        return "@App/admin/admin/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 62,  166 => 61,  145 => 54,  138 => 50,  132 => 47,  128 => 46,  124 => 45,  120 => 44,  116 => 43,  112 => 41,  95 => 40,  92 => 39,  90 => 38,  59 => 10,  52 => 5,  43 => 4,  33 => 1,  31 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@App/admin/master/layout.html.twig' %}
{% set page_title = 'Administratori' %}

{% block body %}

    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">
            Modul Administratora

            <a href=\"{{ path('admin_admins_create') }}\" class=\"btn btn-success\" style=\"float: right;\">
                Dodaj Novog
            </a>
        </h1>
    </div>

    <div class=\"col-lg-12\">
        <div class=\"panel panel-default\">

            <div class=\"panel-heading\">
                Naziv Tabele
            </div>

            <div class=\"panel-body\">
                <div>
                    <table class=\"table table-striped table-bordered table-hover\">
                        <thead>
                            <tr>
                                <th style=\"width: 4%\">#</th>
                                <th class=\"text-center\">Ime</th>
                                <th class=\"text-center\">Prezime</th>
                                <th class=\"text-center\">Email</th>
                                <th class=\"text-center\">Sifra</th>
                                <th class=\"text-center\" style=\"width: 20%\">Akcije</th>
                            </tr>
                        </thead>
                        <tbody>

                        {% if admins is not empty %}

                            {% for admin in admins %}
                            <tr>

                                <td class=\"text-center\">{{ loop.index }}</td>
                                <td class=\"text-center\">{{ admin.firstName }}</td>
                                <td class=\"text-center\">{{ admin.lastName }}</td>
                                <td class=\"text-center\">{{ admin.email }}</td>
                                <td class=\"text-center\">{{ admin.password }}</td>

                                <td class=\"text-center\">
                                    <a href=\"{{ path('admin_admins_edit', {'id': admin.getId()}) }}\"
                                       class=\"btn btn-primary\">
                                       <i class=\"fa fa-pencil\"></i>
                                    </a>
                                    <a href=\"{{ path('admin_admins_delete', {'id': admin.getId()}) }}\" class=\"btn btn-danger\">
                                        <i class=\"fa fa-trash\"></i>
                                    </a>
                                </td>

                            </tr>
                            {% endfor %}
                        {% endif %}

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

{% endblock %}", "@App/admin/admin/index.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\admin\\admin\\index.html.twig");
    }
}
