<?php

/* @App/admin/index/index.html.twig */
class __TwigTemplate_d18562f94c529c1978d38625ed22380e1675f9f952e7e15360d9f9e42bb60007 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/admin/master/layout.html.twig", "@App/admin/index/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/admin/master/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_829c318268165c1ee292601cd0adf0705b29494a2ebb85e2b1c629b94f233f40 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_829c318268165c1ee292601cd0adf0705b29494a2ebb85e2b1c629b94f233f40->enter($__internal_829c318268165c1ee292601cd0adf0705b29494a2ebb85e2b1c629b94f233f40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/index/index.html.twig"));

        $__internal_d2aded7755ed5f543aa74364752bcb1eb32bc78292a23292a3c0c70333d9aa44 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2aded7755ed5f543aa74364752bcb1eb32bc78292a23292a3c0c70333d9aa44->enter($__internal_d2aded7755ed5f543aa74364752bcb1eb32bc78292a23292a3c0c70333d9aa44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/index/index.html.twig"));

        // line 2
        $context["page_title"] = "Home";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_829c318268165c1ee292601cd0adf0705b29494a2ebb85e2b1c629b94f233f40->leave($__internal_829c318268165c1ee292601cd0adf0705b29494a2ebb85e2b1c629b94f233f40_prof);

        
        $__internal_d2aded7755ed5f543aa74364752bcb1eb32bc78292a23292a3c0c70333d9aa44->leave($__internal_d2aded7755ed5f543aa74364752bcb1eb32bc78292a23292a3c0c70333d9aa44_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_8aab5f3fc1cce5654ffcb75994836b36121ea21cf9892ac3632d3c08c038d40c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8aab5f3fc1cce5654ffcb75994836b36121ea21cf9892ac3632d3c08c038d40c->enter($__internal_8aab5f3fc1cce5654ffcb75994836b36121ea21cf9892ac3632d3c08c038d40c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fea7309cdd891ed38b99d48c420ef58d5dffafb1fbdd505160da6a55979780bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fea7309cdd891ed38b99d48c420ef58d5dffafb1fbdd505160da6a55979780bf->enter($__internal_fea7309cdd891ed38b99d48c420ef58d5dffafb1fbdd505160da6a55979780bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">Welcome</h1>
    </div>

";
        
        $__internal_fea7309cdd891ed38b99d48c420ef58d5dffafb1fbdd505160da6a55979780bf->leave($__internal_fea7309cdd891ed38b99d48c420ef58d5dffafb1fbdd505160da6a55979780bf_prof);

        
        $__internal_8aab5f3fc1cce5654ffcb75994836b36121ea21cf9892ac3632d3c08c038d40c->leave($__internal_8aab5f3fc1cce5654ffcb75994836b36121ea21cf9892ac3632d3c08c038d40c_prof);

    }

    public function getTemplateName()
    {
        return "@App/admin/index/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 5,  43 => 4,  33 => 1,  31 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@App/admin/master/layout.html.twig' %}
{% set page_title = 'Home' %}

{% block body %}

    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">Welcome</h1>
    </div>

{% endblock %}", "@App/admin/index/index.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\admin\\index\\index.html.twig");
    }
}
