<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0fd258d5cd90e6569d1ab61f7a8b5064101977573920a7e0c68993aed9a371c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b928237a5e3f1432e3b73cb37e7ac1a2b19b2aee10b03d5919466ad3c06200d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b928237a5e3f1432e3b73cb37e7ac1a2b19b2aee10b03d5919466ad3c06200d6->enter($__internal_b928237a5e3f1432e3b73cb37e7ac1a2b19b2aee10b03d5919466ad3c06200d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_da8d8d6acf287e0b7e299db608be1646d86749ca7528974f5267bd084833cd5a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da8d8d6acf287e0b7e299db608be1646d86749ca7528974f5267bd084833cd5a->enter($__internal_da8d8d6acf287e0b7e299db608be1646d86749ca7528974f5267bd084833cd5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b928237a5e3f1432e3b73cb37e7ac1a2b19b2aee10b03d5919466ad3c06200d6->leave($__internal_b928237a5e3f1432e3b73cb37e7ac1a2b19b2aee10b03d5919466ad3c06200d6_prof);

        
        $__internal_da8d8d6acf287e0b7e299db608be1646d86749ca7528974f5267bd084833cd5a->leave($__internal_da8d8d6acf287e0b7e299db608be1646d86749ca7528974f5267bd084833cd5a_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_b2f188d4f3d57a6ba5c4be8df7883840dfeff0fa416d2419016fc92eb85d3d11 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2f188d4f3d57a6ba5c4be8df7883840dfeff0fa416d2419016fc92eb85d3d11->enter($__internal_b2f188d4f3d57a6ba5c4be8df7883840dfeff0fa416d2419016fc92eb85d3d11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_fe4f5d6f60fb07263983f0be93e426a1e36fe42c8869a48cc26018bbb3a7e4e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe4f5d6f60fb07263983f0be93e426a1e36fe42c8869a48cc26018bbb3a7e4e0->enter($__internal_fe4f5d6f60fb07263983f0be93e426a1e36fe42c8869a48cc26018bbb3a7e4e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_fe4f5d6f60fb07263983f0be93e426a1e36fe42c8869a48cc26018bbb3a7e4e0->leave($__internal_fe4f5d6f60fb07263983f0be93e426a1e36fe42c8869a48cc26018bbb3a7e4e0_prof);

        
        $__internal_b2f188d4f3d57a6ba5c4be8df7883840dfeff0fa416d2419016fc92eb85d3d11->leave($__internal_b2f188d4f3d57a6ba5c4be8df7883840dfeff0fa416d2419016fc92eb85d3d11_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a37ddf3d561b4a2e4e6af5510fe83cfa5e61bf5a72dd9debdace883bdc602f89 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a37ddf3d561b4a2e4e6af5510fe83cfa5e61bf5a72dd9debdace883bdc602f89->enter($__internal_a37ddf3d561b4a2e4e6af5510fe83cfa5e61bf5a72dd9debdace883bdc602f89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e94858fc3ea5236e41eaf9121607260a0203a28493cc74434894da3298498e73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e94858fc3ea5236e41eaf9121607260a0203a28493cc74434894da3298498e73->enter($__internal_e94858fc3ea5236e41eaf9121607260a0203a28493cc74434894da3298498e73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e94858fc3ea5236e41eaf9121607260a0203a28493cc74434894da3298498e73->leave($__internal_e94858fc3ea5236e41eaf9121607260a0203a28493cc74434894da3298498e73_prof);

        
        $__internal_a37ddf3d561b4a2e4e6af5510fe83cfa5e61bf5a72dd9debdace883bdc602f89->leave($__internal_a37ddf3d561b4a2e4e6af5510fe83cfa5e61bf5a72dd9debdace883bdc602f89_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_50f1eb68b973d2c2cd51156fdbb1ccd6abbc0487a7fb71ede8d7d9d09670c297 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50f1eb68b973d2c2cd51156fdbb1ccd6abbc0487a7fb71ede8d7d9d09670c297->enter($__internal_50f1eb68b973d2c2cd51156fdbb1ccd6abbc0487a7fb71ede8d7d9d09670c297_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_c41550385748fe88697d0a061c233b2377b7390b7c4af9da9ea0d5b6e560f70b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c41550385748fe88697d0a061c233b2377b7390b7c4af9da9ea0d5b6e560f70b->enter($__internal_c41550385748fe88697d0a061c233b2377b7390b7c4af9da9ea0d5b6e560f70b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_c41550385748fe88697d0a061c233b2377b7390b7c4af9da9ea0d5b6e560f70b->leave($__internal_c41550385748fe88697d0a061c233b2377b7390b7c4af9da9ea0d5b6e560f70b_prof);

        
        $__internal_50f1eb68b973d2c2cd51156fdbb1ccd6abbc0487a7fb71ede8d7d9d09670c297->leave($__internal_50f1eb68b973d2c2cd51156fdbb1ccd6abbc0487a7fb71ede8d7d9d09670c297_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
