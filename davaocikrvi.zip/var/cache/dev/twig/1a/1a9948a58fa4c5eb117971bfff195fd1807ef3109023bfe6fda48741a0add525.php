<?php

/* @App/front/master/navigationbar.html.twig */
class __TwigTemplate_090aac7674ce4a6e08ca764fe561399b438a905395b08f2fd1b69ee7b452d91b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_41769025fdc1a1f5a3da12d8085ae7e36e9d01e2fd757083682565df5704bb4b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41769025fdc1a1f5a3da12d8085ae7e36e9d01e2fd757083682565df5704bb4b->enter($__internal_41769025fdc1a1f5a3da12d8085ae7e36e9d01e2fd757083682565df5704bb4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/front/master/navigationbar.html.twig"));

        $__internal_4d2d37c02bb35bfbbd0c6d455ee732af895cfa3d508c4e175627deca9f509f26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d2d37c02bb35bfbbd0c6d455ee732af895cfa3d508c4e175627deca9f509f26->enter($__internal_4d2d37c02bb35bfbbd0c6d455ee732af895cfa3d508c4e175627deca9f509f26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/front/master/navigationbar.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
    <div class=\"container\">

        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("front_homepage");
        echo "\">
                Davaoci Krvi
            </a>
        </div>

        <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
            <ul class=\"nav navbar-nav\">

                <!-- OVDE DODAJETE MENIJE ZA PRISTUP STRANICAMA NA FRONTU -->
                <li>
                    <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("front_homepage");
        echo "\">
                        Početna
                    </a>
                    
                </li>
                <li>
                 <a href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blood_request");
        echo "\">
                        Popuni zahtev
                    </a> 
                 </li>       
                        
            </ul>
        </div>

    </div>
</nav>";
        
        $__internal_41769025fdc1a1f5a3da12d8085ae7e36e9d01e2fd757083682565df5704bb4b->leave($__internal_41769025fdc1a1f5a3da12d8085ae7e36e9d01e2fd757083682565df5704bb4b_prof);

        
        $__internal_4d2d37c02bb35bfbbd0c6d455ee732af895cfa3d508c4e175627deca9f509f26->leave($__internal_4d2d37c02bb35bfbbd0c6d455ee732af895cfa3d508c4e175627deca9f509f26_prof);

    }

    public function getTemplateName()
    {
        return "@App/front/master/navigationbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 27,  50 => 21,  37 => 11,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
    <div class=\"container\">

        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"{{ path('front_homepage') }}\">
                Davaoci Krvi
            </a>
        </div>

        <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
            <ul class=\"nav navbar-nav\">

                <!-- OVDE DODAJETE MENIJE ZA PRISTUP STRANICAMA NA FRONTU -->
                <li>
                    <a href=\"{{ path('front_homepage') }}\">
                        Početna
                    </a>
                    
                </li>
                <li>
                 <a href=\"{{ path('blood_request') }}\">
                        Popuni zahtev
                    </a> 
                 </li>       
                        
            </ul>
        </div>

    </div>
</nav>", "@App/front/master/navigationbar.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\front\\master\\navigationbar.html.twig");
    }
}
