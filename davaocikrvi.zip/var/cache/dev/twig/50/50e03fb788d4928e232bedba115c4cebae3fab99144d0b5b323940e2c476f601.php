<?php

/* @App/admin/master/sidebar.html.twig */
class __TwigTemplate_e695fefb86c3f49ca07ce95fed7345a6aab327a64d30ea96278f6ca26cf9d05e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78255217c25a4e32d89e655a61a019c233db7e131858b77e2e15077ac86b4360 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78255217c25a4e32d89e655a61a019c233db7e131858b77e2e15077ac86b4360->enter($__internal_78255217c25a4e32d89e655a61a019c233db7e131858b77e2e15077ac86b4360_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/master/sidebar.html.twig"));

        $__internal_8a21babb0ee55fba21663c73ace6d920c9644ba89e3bd453c7db9257c1ee549f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a21babb0ee55fba21663c73ace6d920c9644ba89e3bd453c7db9257c1ee549f->enter($__internal_8a21babb0ee55fba21663c73ace6d920c9644ba89e3bd453c7db9257c1ee549f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/master/sidebar.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-default navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">

    <div class=\"navbar-header\">
        <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
        </button>
        <a class=\"navbar-brand\" href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_homepage");
        echo "\">CMS Admin</a>
    </div>

    <ul class=\"nav navbar-top-links navbar-right\">
    </ul>


    <div class=\"navbar-default sidebar\" role=\"navigation\">
        <div class=\"sidebar-nav navbar-collapse\">
            <ul class=\"nav\" id=\"side-menu\">

                <!-- OVDE TREBA DA VAM IDU SVI MENIJI KOJI SE VEZUJU PREKO RUTA ZA KONTROLERE I AKCIJE -->
                <li>
                    <a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_homepage");
        echo "\">
                        <i class=\"fa fa-home\"></i> Dashboard
                    </a>
                </li>

                <li>
                    <a href=\"#\">
                        <i class=\"fa fa-map-marker\"></i> Lokacije
                        <span class=\"fa arrow\"></span>
                    </a>
                    <ul class=\"nav nav-second-level collapse\" aria-expanded=\"false\">
                        <li>
                            <a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_countries");
        echo "\"> Države </a>
                        </li>
                        <li>
                            <a> Gradovi </a>
                        </li>
                    </ul>
                </li>
                
                 <li>
                    <a href=\"#\">
                        <i class=\"fa fa-map-marker\"></i> Administratori
                        <span class=\"fa arrow\"></span>
                    </a>
                    <ul class=\"nav nav-second-level collapse\" aria-expanded=\"false\">
                        <li>
                            <a href=\"";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_admins");
        echo "\"> Admin </a>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>
    </div>

</nav>";
        
        $__internal_78255217c25a4e32d89e655a61a019c233db7e131858b77e2e15077ac86b4360->leave($__internal_78255217c25a4e32d89e655a61a019c233db7e131858b77e2e15077ac86b4360_prof);

        
        $__internal_8a21babb0ee55fba21663c73ace6d920c9644ba89e3bd453c7db9257c1ee549f->leave($__internal_8a21babb0ee55fba21663c73ace6d920c9644ba89e3bd453c7db9257c1ee549f_prof);

    }

    public function getTemplateName()
    {
        return "@App/admin/master/sidebar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 50,  67 => 35,  52 => 23,  36 => 10,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<nav class=\"navbar navbar-default navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">

    <div class=\"navbar-header\">
        <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
        </button>
        <a class=\"navbar-brand\" href=\"{{ path('admin_homepage') }}\">CMS Admin</a>
    </div>

    <ul class=\"nav navbar-top-links navbar-right\">
    </ul>


    <div class=\"navbar-default sidebar\" role=\"navigation\">
        <div class=\"sidebar-nav navbar-collapse\">
            <ul class=\"nav\" id=\"side-menu\">

                <!-- OVDE TREBA DA VAM IDU SVI MENIJI KOJI SE VEZUJU PREKO RUTA ZA KONTROLERE I AKCIJE -->
                <li>
                    <a href=\"{{ path('admin_homepage') }}\">
                        <i class=\"fa fa-home\"></i> Dashboard
                    </a>
                </li>

                <li>
                    <a href=\"#\">
                        <i class=\"fa fa-map-marker\"></i> Lokacije
                        <span class=\"fa arrow\"></span>
                    </a>
                    <ul class=\"nav nav-second-level collapse\" aria-expanded=\"false\">
                        <li>
                            <a href=\"{{ path('admin_countries') }}\"> Države </a>
                        </li>
                        <li>
                            <a> Gradovi </a>
                        </li>
                    </ul>
                </li>
                
                 <li>
                    <a href=\"#\">
                        <i class=\"fa fa-map-marker\"></i> Administratori
                        <span class=\"fa arrow\"></span>
                    </a>
                    <ul class=\"nav nav-second-level collapse\" aria-expanded=\"false\">
                        <li>
                            <a href=\"{{ path('admin_admins') }}\"> Admin </a>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>
    </div>

</nav>", "@App/admin/master/sidebar.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\admin\\master\\sidebar.html.twig");
    }
}
