<?php

/* @App/admin/master/layout.html.twig */
class __TwigTemplate_423f0602b15637b100328b2fa58990cd8e5d863bdec80cd2bd83da1c963fbb20 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f15a52e6b3c91e040a36ef2125913c3beefd1af8c2fa7ff56fc9d0b8144f24b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f15a52e6b3c91e040a36ef2125913c3beefd1af8c2fa7ff56fc9d0b8144f24b->enter($__internal_7f15a52e6b3c91e040a36ef2125913c3beefd1af8c2fa7ff56fc9d0b8144f24b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/master/layout.html.twig"));

        $__internal_b6a689a4421754e4265381d5ceaed54086dbd4ef70f22f6eed84248952d151d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6a689a4421754e4265381d5ceaed54086dbd4ef70f22f6eed84248952d151d9->enter($__internal_b6a689a4421754e4265381d5ceaed54086dbd4ef70f22f6eed84248952d151d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/master/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>
        ";
        // line 12
        if (array_key_exists("page_title", $context)) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["page_title"]) ? $context["page_title"] : $this->getContext($context, "page_title")), "html", null, true);
            echo " | Admin ";
        }
        // line 13
        echo "    </title>

    ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 21
        echo "
</head>

<body>

    <div id=\"wrapper\">

        <!-- Sidebar to be included for navigating trough admin cms -->
        ";
        // line 29
        $this->loadTemplate("@App/admin/master/sidebar.html.twig", "@App/admin/master/layout.html.twig", 29)->display($context);
        // line 30
        echo "
        <div id=\"page-wrapper\">
            <div class=\"container-fluid\">
                <div class=\"row\">

                    ";
        // line 35
        $this->displayBlock('body', $context, $blocks);
        // line 36
        echo "
                </div>
            </div>
        </div>

    </div>

    ";
        // line 43
        $this->displayBlock('javascripts', $context, $blocks);
        // line 49
        echo "
    </body>
</html>
";
        
        $__internal_7f15a52e6b3c91e040a36ef2125913c3beefd1af8c2fa7ff56fc9d0b8144f24b->leave($__internal_7f15a52e6b3c91e040a36ef2125913c3beefd1af8c2fa7ff56fc9d0b8144f24b_prof);

        
        $__internal_b6a689a4421754e4265381d5ceaed54086dbd4ef70f22f6eed84248952d151d9->leave($__internal_b6a689a4421754e4265381d5ceaed54086dbd4ef70f22f6eed84248952d151d9_prof);

    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_8e00abace8f2249474ddcffd2d96b8d5c7d2d05d2cc74eb78032fc517ec2e414 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e00abace8f2249474ddcffd2d96b8d5c7d2d05d2cc74eb78032fc517ec2e414->enter($__internal_8e00abace8f2249474ddcffd2d96b8d5c7d2d05d2cc74eb78032fc517ec2e414_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_22934ac693973390e2d75bcb1b939240893c2e175414ca860b85bb31b6439d9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22934ac693973390e2d75bcb1b939240893c2e175414ca860b85bb31b6439d9b->enter($__internal_22934ac693973390e2d75bcb1b939240893c2e175414ca860b85bb31b6439d9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 16
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/admin/vendor/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/admin/vendor/metisMenu/metisMenu.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/admin/dist/css/sb-admin-2.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/admin/vendor/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    ";
        
        $__internal_22934ac693973390e2d75bcb1b939240893c2e175414ca860b85bb31b6439d9b->leave($__internal_22934ac693973390e2d75bcb1b939240893c2e175414ca860b85bb31b6439d9b_prof);

        
        $__internal_8e00abace8f2249474ddcffd2d96b8d5c7d2d05d2cc74eb78032fc517ec2e414->leave($__internal_8e00abace8f2249474ddcffd2d96b8d5c7d2d05d2cc74eb78032fc517ec2e414_prof);

    }

    // line 35
    public function block_body($context, array $blocks = array())
    {
        $__internal_6c26114343a10110a53d7c60657a64c8bf9a9903114502450179b668a64ddf47 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c26114343a10110a53d7c60657a64c8bf9a9903114502450179b668a64ddf47->enter($__internal_6c26114343a10110a53d7c60657a64c8bf9a9903114502450179b668a64ddf47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_cdcc4d840c50ce5743e4a5311fd43f2227476b5a697c7b2ce6fc4f822ee76726 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cdcc4d840c50ce5743e4a5311fd43f2227476b5a697c7b2ce6fc4f822ee76726->enter($__internal_cdcc4d840c50ce5743e4a5311fd43f2227476b5a697c7b2ce6fc4f822ee76726_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_cdcc4d840c50ce5743e4a5311fd43f2227476b5a697c7b2ce6fc4f822ee76726->leave($__internal_cdcc4d840c50ce5743e4a5311fd43f2227476b5a697c7b2ce6fc4f822ee76726_prof);

        
        $__internal_6c26114343a10110a53d7c60657a64c8bf9a9903114502450179b668a64ddf47->leave($__internal_6c26114343a10110a53d7c60657a64c8bf9a9903114502450179b668a64ddf47_prof);

    }

    // line 43
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_82bb53cf38fa5bc9bd158aec9a121225e9beb5474e9c1390034cef3534f39cf9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82bb53cf38fa5bc9bd158aec9a121225e9beb5474e9c1390034cef3534f39cf9->enter($__internal_82bb53cf38fa5bc9bd158aec9a121225e9beb5474e9c1390034cef3534f39cf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_0c604b307750ad15ea8e04dd0991510e842b267b6eea795851a54a1aa8f0dc33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c604b307750ad15ea8e04dd0991510e842b267b6eea795851a54a1aa8f0dc33->enter($__internal_0c604b307750ad15ea8e04dd0991510e842b267b6eea795851a54a1aa8f0dc33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 44
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/admin/vendor/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/admin/vendor/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/admin/vendor/metisMenu/metisMenu.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/admin/dist/js/sb-admin-2.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_0c604b307750ad15ea8e04dd0991510e842b267b6eea795851a54a1aa8f0dc33->leave($__internal_0c604b307750ad15ea8e04dd0991510e842b267b6eea795851a54a1aa8f0dc33_prof);

        
        $__internal_82bb53cf38fa5bc9bd158aec9a121225e9beb5474e9c1390034cef3534f39cf9->leave($__internal_82bb53cf38fa5bc9bd158aec9a121225e9beb5474e9c1390034cef3534f39cf9_prof);

    }

    public function getTemplateName()
    {
        return "@App/admin/master/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 47,  167 => 46,  163 => 45,  158 => 44,  149 => 43,  132 => 35,  120 => 19,  116 => 18,  112 => 17,  107 => 16,  98 => 15,  85 => 49,  83 => 43,  74 => 36,  72 => 35,  65 => 30,  63 => 29,  53 => 21,  51 => 15,  47 => 13,  41 => 12,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>
        {% if page_title is defined %} {{ page_title }} | Admin {% endif %}
    </title>

    {% block stylesheets %}
        <link href=\"{{ asset('skins/admin/vendor/bootstrap/css/bootstrap.min.css') }}\" rel=\"stylesheet\">
        <link href=\"{{ asset('skins/admin/vendor/metisMenu/metisMenu.min.css') }}\" rel=\"stylesheet\">
        <link href=\"{{ asset('skins/admin/dist/css/sb-admin-2.css') }}\" rel=\"stylesheet\">
        <link href=\"{{ asset('skins/admin/vendor/font-awesome/css/font-awesome.min.css') }}\" rel=\"stylesheet\">
    {% endblock %}

</head>

<body>

    <div id=\"wrapper\">

        <!-- Sidebar to be included for navigating trough admin cms -->
        {% include '@App/admin/master/sidebar.html.twig' %}

        <div id=\"page-wrapper\">
            <div class=\"container-fluid\">
                <div class=\"row\">

                    {% block body %}{% endblock %}

                </div>
            </div>
        </div>

    </div>

    {% block javascripts %}
        <script src=\"{{ asset('skins/admin/vendor/jquery/jquery.min.js') }}\"></script>
        <script src=\"{{ asset('skins/admin/vendor/bootstrap/js/bootstrap.min.js') }}\"></script>
        <script src=\"{{ asset('skins/admin/vendor/metisMenu/metisMenu.min.js') }}\"></script>
        <script src=\"{{ asset('skins/admin/dist/js/sb-admin-2.js') }}\"></script>
    {% endblock %}

    </body>
</html>
", "@App/admin/master/layout.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\admin\\master\\layout.html.twig");
    }
}
