<?php

/* @App/front/master/layout.html.twig */
class __TwigTemplate_bc9230b1161c8e77439e2fca12a13e294ad0b36c06ccef8d01aef453a7c04759 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_81f37fb953d56ba7d0f76b9e311398af0ee1f1deac8f9b9ad10a76d56d0ad100 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_81f37fb953d56ba7d0f76b9e311398af0ee1f1deac8f9b9ad10a76d56d0ad100->enter($__internal_81f37fb953d56ba7d0f76b9e311398af0ee1f1deac8f9b9ad10a76d56d0ad100_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/front/master/layout.html.twig"));

        $__internal_b244aa2633cf2cacdd4bfd6edc1f2dc06b0d7cb0e41ceef21bc5a0485f2d5bc8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b244aa2633cf2cacdd4bfd6edc1f2dc06b0d7cb0e41ceef21bc5a0485f2d5bc8->enter($__internal_b244aa2633cf2cacdd4bfd6edc1f2dc06b0d7cb0e41ceef21bc5a0485f2d5bc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/front/master/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>
        ";
        // line 12
        if (array_key_exists("page_title", $context)) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["page_title"]) ? $context["page_title"] : $this->getContext($context, "page_title")), "html", null, true);
            echo " | Davaoci Krvi ";
        }
        // line 13
        echo "    </title>

    ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 19
        echo "
</head>

<body>

    ";
        // line 24
        $this->loadTemplate("@App/front/master/navigationbar.html.twig", "@App/front/master/layout.html.twig", 24)->display($context);
        // line 25
        echo "
    <div class=\"container\">

        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">

                ";
        // line 31
        $this->displayBlock('body', $context, $blocks);
        // line 32
        echo "
            </div>
        </div>

    </div>

    ";
        // line 38
        $this->displayBlock('javascripts', $context, $blocks);
        // line 42
        echo "
</body>
</html>
";
        
        $__internal_81f37fb953d56ba7d0f76b9e311398af0ee1f1deac8f9b9ad10a76d56d0ad100->leave($__internal_81f37fb953d56ba7d0f76b9e311398af0ee1f1deac8f9b9ad10a76d56d0ad100_prof);

        
        $__internal_b244aa2633cf2cacdd4bfd6edc1f2dc06b0d7cb0e41ceef21bc5a0485f2d5bc8->leave($__internal_b244aa2633cf2cacdd4bfd6edc1f2dc06b0d7cb0e41ceef21bc5a0485f2d5bc8_prof);

    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_46e82098561dd33f30de7ea1c769efecb78a57a10fad38057118c1f1d1dc132c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46e82098561dd33f30de7ea1c769efecb78a57a10fad38057118c1f1d1dc132c->enter($__internal_46e82098561dd33f30de7ea1c769efecb78a57a10fad38057118c1f1d1dc132c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_1799f22f233d4df7d912386af0e8cc67cc0ad77fdc4df461b7c108522a2b9a71 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1799f22f233d4df7d912386af0e8cc67cc0ad77fdc4df461b7c108522a2b9a71->enter($__internal_1799f22f233d4df7d912386af0e8cc67cc0ad77fdc4df461b7c108522a2b9a71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 16
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/front/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <style> body {padding-top: 70px;} </style>
    ";
        
        $__internal_1799f22f233d4df7d912386af0e8cc67cc0ad77fdc4df461b7c108522a2b9a71->leave($__internal_1799f22f233d4df7d912386af0e8cc67cc0ad77fdc4df461b7c108522a2b9a71_prof);

        
        $__internal_46e82098561dd33f30de7ea1c769efecb78a57a10fad38057118c1f1d1dc132c->leave($__internal_46e82098561dd33f30de7ea1c769efecb78a57a10fad38057118c1f1d1dc132c_prof);

    }

    // line 31
    public function block_body($context, array $blocks = array())
    {
        $__internal_f9e3dc7cb04b32fd3490b563ec967d5d108c3461e405a67ac7a42f8b84a6b2ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f9e3dc7cb04b32fd3490b563ec967d5d108c3461e405a67ac7a42f8b84a6b2ff->enter($__internal_f9e3dc7cb04b32fd3490b563ec967d5d108c3461e405a67ac7a42f8b84a6b2ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fedaf33e662d91ddfefd6ec3e18fecc7c3dcfed41f7f426c3cf376667c8f5cc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fedaf33e662d91ddfefd6ec3e18fecc7c3dcfed41f7f426c3cf376667c8f5cc5->enter($__internal_fedaf33e662d91ddfefd6ec3e18fecc7c3dcfed41f7f426c3cf376667c8f5cc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_fedaf33e662d91ddfefd6ec3e18fecc7c3dcfed41f7f426c3cf376667c8f5cc5->leave($__internal_fedaf33e662d91ddfefd6ec3e18fecc7c3dcfed41f7f426c3cf376667c8f5cc5_prof);

        
        $__internal_f9e3dc7cb04b32fd3490b563ec967d5d108c3461e405a67ac7a42f8b84a6b2ff->leave($__internal_f9e3dc7cb04b32fd3490b563ec967d5d108c3461e405a67ac7a42f8b84a6b2ff_prof);

    }

    // line 38
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_daa6ed8ab1b7645eac105f06c5d2728b7af31bd2bf5441e2e51464949ff57ad0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_daa6ed8ab1b7645eac105f06c5d2728b7af31bd2bf5441e2e51464949ff57ad0->enter($__internal_daa6ed8ab1b7645eac105f06c5d2728b7af31bd2bf5441e2e51464949ff57ad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_ac818dcf4e6c34049138f30d2071c992559415c643ad1b257822c409937d3f99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac818dcf4e6c34049138f30d2071c992559415c643ad1b257822c409937d3f99->enter($__internal_ac818dcf4e6c34049138f30d2071c992559415c643ad1b257822c409937d3f99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 39
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/front/js/jquery.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("skins/front/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_ac818dcf4e6c34049138f30d2071c992559415c643ad1b257822c409937d3f99->leave($__internal_ac818dcf4e6c34049138f30d2071c992559415c643ad1b257822c409937d3f99_prof);

        
        $__internal_daa6ed8ab1b7645eac105f06c5d2728b7af31bd2bf5441e2e51464949ff57ad0->leave($__internal_daa6ed8ab1b7645eac105f06c5d2728b7af31bd2bf5441e2e51464949ff57ad0_prof);

    }

    public function getTemplateName()
    {
        return "@App/front/master/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 40,  144 => 39,  135 => 38,  118 => 31,  104 => 16,  95 => 15,  82 => 42,  80 => 38,  72 => 32,  70 => 31,  62 => 25,  60 => 24,  53 => 19,  51 => 15,  47 => 13,  41 => 12,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>
        {% if page_title is defined %} {{ page_title }} | Davaoci Krvi {% endif %}
    </title>

    {% block stylesheets %}
        <link href=\"{{ asset('skins/front/css/bootstrap.min.css') }}\" rel=\"stylesheet\">
        <style> body {padding-top: 70px;} </style>
    {% endblock %}

</head>

<body>

    {% include '@App/front/master/navigationbar.html.twig'%}

    <div class=\"container\">

        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">

                {% block body %}{% endblock %}

            </div>
        </div>

    </div>

    {% block javascripts %}
        <script src=\"{{ asset('skins/front/js/jquery.js') }}\"></script>
        <script src=\"{{ asset('skins/front/js/bootstrap.min.js') }}\"></script>
    {% endblock %}

</body>
</html>
", "@App/front/master/layout.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\front\\master\\layout.html.twig");
    }
}
