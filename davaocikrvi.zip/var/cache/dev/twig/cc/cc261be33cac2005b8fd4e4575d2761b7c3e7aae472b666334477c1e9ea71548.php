<?php

/* @App/admin/country/index.html.twig */
class __TwigTemplate_8d52573d4c4e4bfe36841596c7d385b918166db454161f82d3f21c485a813cf1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/admin/master/layout.html.twig", "@App/admin/country/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/admin/master/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a405fb5a891181a2f1f64ab82df5fa7fd53fc6c2125b6aa0c7848ea3eec32063 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a405fb5a891181a2f1f64ab82df5fa7fd53fc6c2125b6aa0c7848ea3eec32063->enter($__internal_a405fb5a891181a2f1f64ab82df5fa7fd53fc6c2125b6aa0c7848ea3eec32063_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/country/index.html.twig"));

        $__internal_a09d497f3ca3799a67a452dd66ebbdd70e331402c193b97966c3f7ec5d295b3e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a09d497f3ca3799a67a452dd66ebbdd70e331402c193b97966c3f7ec5d295b3e->enter($__internal_a09d497f3ca3799a67a452dd66ebbdd70e331402c193b97966c3f7ec5d295b3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/admin/country/index.html.twig"));

        // line 2
        $context["page_title"] = "Države";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a405fb5a891181a2f1f64ab82df5fa7fd53fc6c2125b6aa0c7848ea3eec32063->leave($__internal_a405fb5a891181a2f1f64ab82df5fa7fd53fc6c2125b6aa0c7848ea3eec32063_prof);

        
        $__internal_a09d497f3ca3799a67a452dd66ebbdd70e331402c193b97966c3f7ec5d295b3e->leave($__internal_a09d497f3ca3799a67a452dd66ebbdd70e331402c193b97966c3f7ec5d295b3e_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_d3dbaaaeb4e9fb8d6357669fc31de14cf2c2e7f274425279bc44b0c58fee2a00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3dbaaaeb4e9fb8d6357669fc31de14cf2c2e7f274425279bc44b0c58fee2a00->enter($__internal_d3dbaaaeb4e9fb8d6357669fc31de14cf2c2e7f274425279bc44b0c58fee2a00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c2216c8aab29b580635f7d2dd00105b2a80d7754b7a4d8b9965ad3fc907059bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2216c8aab29b580635f7d2dd00105b2a80d7754b7a4d8b9965ad3fc907059bc->enter($__internal_c2216c8aab29b580635f7d2dd00105b2a80d7754b7a4d8b9965ad3fc907059bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">
            Modul Države

            <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_countries_create");
        echo "\" class=\"btn btn-success\" style=\"float: right;\">
                Dodaj Novu
            </a>
        </h1>
    </div>

    <div class=\"col-lg-12\">
        <div class=\"panel panel-default\">

            <div class=\"panel-heading\">
                Naziv Tabele
            </div>

            <div class=\"panel-body\">
                <div>
                    <table class=\"table table-striped table-bordered table-hover\">
                        <thead>
                            <tr>
                                <th style=\"width: 4%\">#</th>
                                <th class=\"text-center\">Ime Države</th>
                                <th class=\"text-center\" style=\"width: 20%\">Akcije</th>
                            </tr>
                        </thead>
                        <tbody>

                        ";
        // line 35
        if ( !twig_test_empty((isset($context["countries"]) ? $context["countries"] : $this->getContext($context, "countries")))) {
            // line 36
            echo "
                            ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["countries"]) ? $context["countries"] : $this->getContext($context, "countries")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
                // line 38
                echo "                            <tr>

                                <td class=\"text-center\">";
                // line 40
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo "</td>
                                <td class=\"text-center\">";
                // line 41
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "name", array()), "html", null, true);
                echo "</td>

                                <td class=\"text-center\">
                                    <a href=\"";
                // line 44
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_countries_edit", array("id" => $this->getAttribute($context["country"], "getId", array(), "method"))), "html", null, true);
                echo "\"
                                       class=\"btn btn-primary\">
                                       <i class=\"fa fa-pencil\"></i>
                                    </a>
                                    <a href=\"";
                // line 48
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_countries_delete", array("id" => $this->getAttribute($context["country"], "getId", array(), "method"))), "html", null, true);
                echo "\" class=\"btn btn-danger\">
                                        <i class=\"fa fa-trash\"></i>
                                    </a>
                                </td>

                            </tr>
                            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 55
            echo "                        ";
        }
        // line 56
        echo "
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_c2216c8aab29b580635f7d2dd00105b2a80d7754b7a4d8b9965ad3fc907059bc->leave($__internal_c2216c8aab29b580635f7d2dd00105b2a80d7754b7a4d8b9965ad3fc907059bc_prof);

        
        $__internal_d3dbaaaeb4e9fb8d6357669fc31de14cf2c2e7f274425279bc44b0c58fee2a00->leave($__internal_d3dbaaaeb4e9fb8d6357669fc31de14cf2c2e7f274425279bc44b0c58fee2a00_prof);

    }

    public function getTemplateName()
    {
        return "@App/admin/country/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 56,  151 => 55,  130 => 48,  123 => 44,  117 => 41,  113 => 40,  109 => 38,  92 => 37,  89 => 36,  87 => 35,  59 => 10,  52 => 5,  43 => 4,  33 => 1,  31 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@App/admin/master/layout.html.twig' %}
{% set page_title = 'Države' %}

{% block body %}

    <div class=\"col-lg-12\">
        <h1 class=\"page-header\">
            Modul Države

            <a href=\"{{ path('admin_countries_create') }}\" class=\"btn btn-success\" style=\"float: right;\">
                Dodaj Novu
            </a>
        </h1>
    </div>

    <div class=\"col-lg-12\">
        <div class=\"panel panel-default\">

            <div class=\"panel-heading\">
                Naziv Tabele
            </div>

            <div class=\"panel-body\">
                <div>
                    <table class=\"table table-striped table-bordered table-hover\">
                        <thead>
                            <tr>
                                <th style=\"width: 4%\">#</th>
                                <th class=\"text-center\">Ime Države</th>
                                <th class=\"text-center\" style=\"width: 20%\">Akcije</th>
                            </tr>
                        </thead>
                        <tbody>

                        {% if countries is not empty %}

                            {% for country in countries %}
                            <tr>

                                <td class=\"text-center\">{{ loop.index }}</td>
                                <td class=\"text-center\">{{ country.name }}</td>

                                <td class=\"text-center\">
                                    <a href=\"{{ path('admin_countries_edit', {'id': country.getId()}) }}\"
                                       class=\"btn btn-primary\">
                                       <i class=\"fa fa-pencil\"></i>
                                    </a>
                                    <a href=\"{{ path('admin_countries_delete', {'id': country.getId()}) }}\" class=\"btn btn-danger\">
                                        <i class=\"fa fa-trash\"></i>
                                    </a>
                                </td>

                            </tr>
                            {% endfor %}
                        {% endif %}

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

{% endblock %}", "@App/admin/country/index.html.twig", "C:\\xampp\\htdocs\\davaocikrvi\\src\\AppBundle\\Resources\\views\\admin\\country\\index.html.twig");
    }
}
